﻿This file appears in <Mod>/ after installing the sample mod.
安装后会在 <Mod>/ 下出现本文件。
