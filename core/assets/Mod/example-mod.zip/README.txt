﻿这是 apk 内置的示例模组。安装后会在 <Mod>/example-mod/ 下出现本文件。
This is a built-in sample mod.
